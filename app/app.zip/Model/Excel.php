<?php
App::uses('AppModel', 'Model');
/**
 * Excel Model
 *
 */
class Excel extends AppModel {

}
